import com.sap.gateway.ip.core.customdev.util.Message

def Message processData(Message message) {
    def csrPEM = message.getProperty("csrPEM")

    if (csrPEM != null) {
        def csr = csrPEM.toString()

        def header = "-----BEGIN CERTIFICATE REQUEST-----"
        def footer = "-----END CERTIFICATE REQUEST-----"

        // Strip header/footer first, then remove ALL remaining whitespace
        // (the base64 body itself never contains spaces, so this is safe)
        def body = csr.replace(header, "")
                      .replace(footer, "")
                      .replaceAll("\\s", "")

        // Re-wrap at 64 chars per line, standard PEM formatting
        def wrapped = body.replaceAll("(.{64})", "\$1\n").trim()

        // Rebuild the PEM — no trailing newline after the footer
        def restoredPem = "${header}\n${wrapped}\n${footer}"

        // Base64-encode the restored PEM text
        def csrBase64 = restoredPem.bytes.encodeBase64().toString()

        message.setProperty("csrBase64", csrBase64)
    }

    return message
}